import React from 'react';
import { Github, Mail, Linkedin, Phone } from 'lucide-react';
import Section from './ui/Section';
import Card from './ui/Card';

const contactData = [
  {
    icon: <Mail className="w-8 h-8 text-indigo-300" />,
    title: "Email",
    value: "thirukumaran754@gmail.com",
    href: "mailto:thirukumaran754@gmail.com"
  },
  {
    icon: <Phone className="w-8 h-8 text-indigo-300" />,
    title: "Phone",
    value: "+91 7540082987",
    href: "tel:+917540082987"
  },
  {
    icon: <Github className="w-8 h-8 text-indigo-300" />,
    title: "GitHub",
    value: "thiru72k",
    href: "https://github.com/thiru72k"
  },
  {
    icon: <Linkedin className="w-8 h-8 text-indigo-300" />,
    title: "LinkedIn",
    value: "Thiru Kumaran",
    href: "https://www.linkedin.com/in/thiru-kumaran-843694268"
  }
];

const ContactCard = ({ contact }: { contact: typeof contactData[0] }) => {
  return (
    <a
      href={contact.href}
      target="_blank"
      rel="noopener noreferrer"
      className="block"
    >
      <Card className="hover:border-indigo-500 transition-colors">
        <div className="flex items-center gap-4">
          {contact.icon}
          <div>
            <h3 className="font-semibold text-indigo-300">{contact.title}</h3>
            <p className="text-gray-300">{contact.value}</p>
          </div>
        </div>
      </Card>
    </a>
  );
};

const Contact = () => {
  return (
    <Section id="contact" title="Get In Touch" dark>
      <div className="max-w-2xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {contactData.map((contact, index) => (
            <ContactCard key={index} contact={contact} />
          ))}
        </div>
      </div>
    </Section>
  );
};

export default Contact;