import React from 'react';
import { Code2, Database, Globe } from 'lucide-react';
import Section from './ui/Section';
import Card from './ui/Card';

const skillsData = [
  {
    category: "Programming",
    icon: <Code2 className="w-8 h-8" />,
    items: ["Python", "C", "C++", "JavaScript"]
  },
  {
    category: "Database",
    icon: <Database className="w-8 h-8" />,
    items: ["PostgreSQL"]
  },
  {
    category: "Web Development",
    icon: <Globe className="w-8 h-8" />,
    items: ["HTML", "CSS", "Node.js"]
  }
];

const SkillCard = ({ skill }: { skill: typeof skillsData[0] }) => {
  return (
    <Card>
      <div className="flex items-center gap-4 mb-4">
        <div className="text-indigo-300">{skill.icon}</div>
        <h3 className="text-xl font-semibold text-indigo-300">{skill.category}</h3>
      </div>
      <ul className="space-y-2">
        {skill.items.map((item, index) => (
          <li key={index} className="flex items-center gap-2">
            <span className="w-2 h-2 bg-indigo-400 rounded-full"></span>
            <span className="text-gray-300">{item}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
};

const Skills = () => {
  return (
    <Section id="skills" title="Technical Skills" dark>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {skillsData.map((skill, index) => (
          <SkillCard key={index} skill={skill} />
        ))}
      </div>
    </Section>
  );
};

export default Skills;