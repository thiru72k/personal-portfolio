import React from 'react';

interface EducationItemProps {
  title: string;
  institution: string;
  period: string;
  score: string;
  scoreLabel: string;
}

function EducationItem({ title, institution, period, score, scoreLabel }: EducationItemProps) {
  return (
    <div>
      <h5 className="text-lg font-medium text-slate-200">{title}</h5>
      <p className="text-slate-400">{institution} ({period})</p>
      <p className="text-indigo-400">{scoreLabel}: {score}</p>
    </div>
  );
}

export default function Education() {
  const educationData = [
    {
      title: "B.E Electrical and Electronics Engineering",
      institution: "Sethu Institute of Technology",
      period: "2021 - 2025",
      score: "8.0",
      scoreLabel: "CGPA"
    },
    {
      title: "HSC",
      institution: "MRR.MAVMM.MATRIC.HR.SEC.SCHOOL",
      period: "2020 - 2021",
      score: "84%",
      scoreLabel: "Percentage"
    }
  ];

  return (
    <div className="border-l-2 border-indigo-500 pl-6">
      <h4 className="text-xl font-semibold text-indigo-300 mb-4">Education</h4>
      <div className="space-y-4">
        {educationData.map((item, index) => (
          <EducationItem key={index} {...item} />
        ))}
      </div>
    </div>
  );
}