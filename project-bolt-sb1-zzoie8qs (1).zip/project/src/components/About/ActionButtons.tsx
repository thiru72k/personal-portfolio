import React from 'react';

interface ActionButtonProps {
  href: string;
  variant: 'primary' | 'secondary';
  children: React.ReactNode;
}

function ActionButton({ href, variant, children }: ActionButtonProps) {
  const baseClasses = "group relative px-8 py-3 rounded-full overflow-hidden";
  const variantClasses = {
    primary: "bg-indigo-600 text-white",
    secondary: "bg-transparent text-indigo-300 border-2 border-indigo-500"
  };

  return (
    <a href={href} className={`${baseClasses} ${variantClasses[variant]}`}>
      <div className="absolute inset-0 bg-indigo-500 translate-y-full transition-transform group-hover:translate-y-0" />
      <span className={`relative ${variant === 'secondary' ? 'group-hover:text-white transition-colors' : ''}`}>
        {children}
      </span>
    </a>
  );
}

export default function ActionButtons() {
  return (
    <div className="flex flex-wrap justify-center gap-6 pt-4">
      <ActionButton href="mailto:thirukumaran754@gmail.com" variant="primary">
        Contact Me
      </ActionButton>
      <ActionButton href="#projects" variant="secondary">
        View Projects
      </ActionButton>
    </div>
  );
}