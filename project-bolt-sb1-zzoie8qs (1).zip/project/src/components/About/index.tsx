import React from 'react';
import Section from '../ui/Section';
import Card from '../ui/Card';
import Education from './Education';
import ActionButtons from './ActionButtons';

export default function About() {
  return (
    <Section id="about" title="About Me">
      <div className="max-w-4xl mx-auto">
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-indigo-900/10 blur-3xl rounded-full" />
          <div className="relative space-y-8">
            <div className="space-y-6">
              <p className="text-lg text-slate-300 leading-relaxed">
                As an Electrical and Electronics Engineering student at Sethu Institute of Technology, 
                I combine my technical foundation with a growing passion for software development. 
                My journey represents a bridge between traditional engineering principles and modern 
                technology solutions.
              </p>
              <Education />
            </div>
            <ActionButtons />
          </div>
        </Card>
      </div>
    </Section>
  );
}