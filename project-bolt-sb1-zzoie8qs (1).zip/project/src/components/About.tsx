import React from 'react';
import Section from './ui/Section';
import Card from './ui/Card';

const About = () => {
  return (
    <Section id="about" title="About Me">
      <div className="max-w-4xl mx-auto">
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-indigo-900/10 blur-3xl rounded-full" />
          <div className="relative space-y-8">
            <div className="space-y-6">
              <p className="text-lg text-slate-300 leading-relaxed">
                As an Electrical and Electronics Engineering student at Sethu Institute of Technology, 
                I combine my technical foundation with a growing passion for software development. 
                My journey represents a bridge between traditional engineering principles and modern 
                technology solutions.
              </p>
              
              <div className="space-y-6">
                <div className="border-l-2 border-indigo-500 pl-6">
                  <h4 className="text-xl font-semibold text-indigo-300 mb-4">Education</h4>
                  <div className="space-y-4">
                    <div>
                      <h5 className="text-lg font-medium text-slate-200">
                        B.E Electrical and Electronics Engineering
                      </h5>
                      <p className="text-slate-400">Sethu Institute of Technology (2021 - 2025)</p>
                      <p className="text-indigo-400">CGPA: 8.0</p>
                    </div>
                    <div>
                      <h5 className="text-lg font-medium text-slate-200">HSC</h5>
                      <p className="text-slate-400">MRR.MAVMM.MATRIC.HR.SEC.SCHOOL (2020 - 2021)</p>
                      <p className="text-indigo-400">Percentage: 84%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-6 pt-4">
              <a
                href="mailto:thirukumaran754@gmail.com"
                className="group relative px-8 py-3 bg-indigo-600 text-white rounded-full overflow-hidden"
              >
                <div className="absolute inset-0 bg-indigo-500 translate-y-full transition-transform group-hover:translate-y-0" />
                <span className="relative">Contact Me</span>
              </a>
              <a
                href="#projects"
                className="group relative px-8 py-3 bg-transparent text-indigo-300 rounded-full overflow-hidden border-2 border-indigo-500"
              >
                <div className="absolute inset-0 bg-indigo-600 translate-y-full transition-transform group-hover:translate-y-0" />
                <span className="relative group-hover:text-white transition-colors">View Projects</span>
              </a>
            </div>
          </div>
        </Card>
      </div>
    </Section>
  );
};

export default About;