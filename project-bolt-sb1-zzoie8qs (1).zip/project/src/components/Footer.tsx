import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-slate-950/50 backdrop-blur-sm text-slate-400 py-6 border-t border-slate-800/50">
      <div className="container mx-auto px-4 text-center">
        <p>© 2024 Thiru Kumaran R. All rights reserved.</p>
      </div>
    </footer>
  );
}