import React from 'react';
import ScrollIndicator from './ScrollIndicator';

export default function Hero() {
  return (
    <section className="min-h-[calc(100vh-5rem)] relative flex items-center justify-center">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-transparent to-transparent" />
      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="space-y-6">
          <h1 className="font-display text-2xl md:text-3xl lg:text-4xl font-bold inline-flex items-center justify-center gap-2">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 to-indigo-200">
              Thiru
            </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 to-indigo-300">
              Kumaran R
            </span>
          </h1>
          <div className="h-px w-24 mx-auto bg-gradient-to-r from-transparent via-indigo-500 to-transparent" />
          <div className="max-w-3xl mx-auto space-y-6 text-slate-300">
            <p className="text-lg md:text-xl font-light leading-relaxed">
              👋 Hi, I'm Thirukumaran R.
            </p>
            <p className="text-base md:text-lg leading-relaxed">
              Welcome to my corner of the web! I'm a passionate Electrical and Electronics Engineer with a strong flair for software development and front-end technologies. My journey bridges the gap between creativity and technology, crafting intuitive and aesthetically pleasing user interfaces.
            </p>
            <div className="space-y-4">
              <h2 className="text-lg md:text-xl font-semibold text-indigo-300">🚀 What I Do:</h2>
              <ul className="space-y-2 text-base">
                <li>Front-End Development: Building interactive and visually captivating web applications.</li>
                <li>Python Development: Developing scalable and efficient solutions for complex problems.</li>
                <li>React Projects: Designing dynamic applications with modern frameworks.</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h2 className="text-lg md:text-xl font-semibold text-indigo-300">✨ Why Visit?</h2>
              <p className="text-base">
                Explore my featured projects, gain insights into my skills, and discover my enthusiasm for creating solutions that make a difference. Don't miss the chance to check out my LinkedIn for a deeper dive into my professional journey.
              </p>
            </div>
            <div className="space-y-2">
              <h2 className="text-lg md:text-xl font-semibold text-indigo-300">🌟 Let's Connect:</h2>
              <p className="text-base">
                I'm always open to opportunities, collaborations, and new ideas. If you're looking for someone to turn your vision into reality, you've come to the right place!
              </p>
            </div>
          </div>
        </div>
        <div className="mt-12">
          <ScrollIndicator />
        </div>
      </div>
    </section>
  );
}