import React from 'react';
import { ArrowDown } from 'lucide-react';

export default function ScrollIndicator() {
  return (
    <a
      href="#about"
      className="inline-flex items-center gap-2 text-indigo-300 hover:text-indigo-200 transition-colors"
    >
      <span>Scroll to explore</span>
      <ArrowDown className="animate-bounce" />
    </a>
  );
}