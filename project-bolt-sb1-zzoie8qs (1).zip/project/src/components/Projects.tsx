import React from 'react';
import { Activity, Cloud } from 'lucide-react';
import Section from './ui/Section';
import Card from './ui/Card';
import Badge from './ui/Badge';

const projectsData = [
  {
    title: "Fitness Tracker Application",
    description: "An interactive fitness tracker application with real-time updates and user-friendly interface.",
    icon: <Activity className="w-12 h-12 text-indigo-300" />,
    technologies: ["Node.js", "HTML", "CSS", "JavaScript"],
    highlights: [
      "Implemented Node.js backend for secure data management",
      "Integrated dynamic features with responsive design",
      "Improved user engagement by 30%"
    ]
  },
  {
    title: "Weather Forecasting Application",
    description: "Python-based weather forecasting application with real-time data integration.",
    icon: <Cloud className="w-12 h-12 text-indigo-300" />,
    technologies: ["Python", "Tkinter", "OpenWeatherMap API"],
    highlights: [
      "Developed user-friendly GUI using Tkinter",
      "Integrated real-time weather data API",
      "Implemented OOP principles for modular design"
    ]
  }
];

const ProjectCard = ({ project }: { project: typeof projectsData[0] }) => {
  return (
    <Card>
      <div className="flex items-center gap-4 mb-4">
        {project.icon}
        <h3 className="text-2xl font-semibold text-indigo-300">{project.title}</h3>
      </div>
      <p className="text-gray-300 mb-4">{project.description}</p>
      <div className="mb-4">
        <h4 className="font-semibold mb-2 text-indigo-200">Technologies:</h4>
        <div className="flex flex-wrap gap-2">
          {project.technologies.map((tech, index) => (
            <Badge key={index}>{tech}</Badge>
          ))}
        </div>
      </div>
      <div>
        <h4 className="font-semibold mb-2 text-indigo-200">Key Highlights:</h4>
        <ul className="list-disc list-inside space-y-1 text-gray-300">
          {project.highlights.map((highlight, index) => (
            <li key={index}>{highlight}</li>
          ))}
        </ul>
      </div>
    </Card>
  );
};

const Projects = () => {
  return (
    <Section id="projects" title="Projects">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {projectsData.map((project, index) => (
          <ProjectCard key={index} project={project} />
        ))}
      </div>
    </Section>
  );
};

export default Projects;