import React from 'react';

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
}

export default function NavLink({ href, children }: NavLinkProps) {
  return (
    <a
      href={href}
      className="text-slate-300 hover:text-indigo-300 transition-colors"
    >
      {children}
    </a>
  );
}