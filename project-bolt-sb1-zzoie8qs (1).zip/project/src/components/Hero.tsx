import React from 'react';
import { ArrowDown } from 'lucide-react';

const Hero = () => {
  return (
    <section className="min-h-[calc(100vh-5rem)] relative flex items-center justify-center">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-transparent to-transparent" />
      <div className="container mx-auto px-4 text-center relative z-10">
        <h1 className="text-6xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 via-indigo-200 to-indigo-300 mb-6">
          Thiru Kumaran R
        </h1>
        <p className="text-xl md:text-2xl text-slate-300 mb-12 max-w-2xl mx-auto">
          Electrical and Electronics Engineering Student passionate about creating innovative solutions
          and transitioning into the IT industry.
        </p>
        <a
          href="#about"
          className="inline-flex items-center gap-2 text-indigo-300 hover:text-indigo-200 transition-colors"
        >
          <span>Scroll to explore</span>
          <ArrowDown className="animate-bounce" />
        </a>
      </div>
    </section>
  );
}

export default Hero;