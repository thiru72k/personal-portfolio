import React, { ReactNode } from 'react';

interface BadgeProps {
  children: ReactNode;
}

const Badge = ({ children }: BadgeProps) => {
  return (
    <span className="bg-indigo-900 text-indigo-200 px-3 py-1 rounded-full text-sm">
      {children}
    </span>
  );
};

export default Badge;